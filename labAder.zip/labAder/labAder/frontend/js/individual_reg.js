// frontend/js/individual_reg.js
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('individualForm');
  if (!form) return;

  // tag/skill UI (keep your logic)
  const skillInput = document.getElementById('skillInput');
  const skillsBox = document.getElementById('skillsInput');
  let skills = [];
  function renderSkills(){
    skillsBox.innerHTML = '';
    skills.forEach((s, idx) => {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.innerHTML = `${s} <span class="remove" data-idx="${idx}">×</span>`;
      skillsBox.appendChild(tag);
    });
    skillsBox.appendChild(skillInput);
    skillInput.value = '';
    skillInput.focus();
  }
  skillsBox.addEventListener('click', () => skillInput.focus());
  skillInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const v = skillInput.value.trim().replace(/,$/,'');
      if (v && !skills.includes(v)) { skills.push(v); renderSkills(); } else skillInput.value = '';
    } else if (e.key === 'Backspace' && skillInput.value === '') {
      skills.pop(); renderSkills();
    }
  });
  skillsBox.addEventListener('click', (e) => {
    if (e.target.classList.contains('remove')) {
      skills.splice(parseInt(e.target.dataset.idx,10),1);
      renderSkills();
    }
  });

  // preview image optional - we won't upload image to server in this version.
  const profilePic = document.getElementById('profilePic');
  const profilePreview = document.getElementById('profilePreview');
  profilePic?.addEventListener('change', () => {
    const file = profilePic.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => {
      profilePreview.innerHTML = `<img src="${reader.result}" alt="Profile preview">`;
    };
    reader.readAsDataURL(file);
  });

  // validation
  function showError(id, msg) { const el = document.getElementById(id); if (el) el.textContent = msg; }
  function clearErrors(){ ['err-fullName','err-primaryField','err-skills','err-email'].forEach(id=>{ const el=document.getElementById(id); if(el) el.textContent=''; });}
  function validate(){
    clearErrors();
    let ok = true;
    if (!document.getElementById('fullName').value.trim()){ showError('err-fullName','Full name is required'); ok=false; }
    if (!document.getElementById('primaryField').value){ showError('err-primaryField','Select a field'); ok=false; }
    if (skills.length === 0){ showError('err-skills','Add at least one skill'); ok=false; }
    const email = document.getElementById('email').value.trim();
    if (!email || !/^\S+@\S+\.\S+$/.test(email)){ showError('err-email','Valid email is required'); ok=false; }
    return ok;
  }

  // save/load draft (localStorage) - keep as convenience
  document.getElementById('saveDraftBtn').addEventListener('click', () => {
    const data = {
      fullName: document.getElementById('fullName').value,
      dob: document.getElementById('dob').value,
      gender: document.getElementById('gender').value,
      primaryField: document.getElementById('primaryField').value,
      subField: document.getElementById('subField').value,
      skills,
      experience: document.getElementById('experience').value,
      degree: document.getElementById('degree').value,
      institution: document.getElementById('institution').value,
      gradYear: document.getElementById('gradYear').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      linkedin: document.getElementById('linkedin').value,
      bio: document.getElementById('bio') ? document.getElementById('bio').value : ''
    };
    localStorage.setItem('individualDraft', JSON.stringify(data));
    alert('Draft saved locally.');
  });

  document.getElementById('loadDraftBtn').addEventListener('click', () => {
    const raw = localStorage.getItem('individualDraft');
    if (!raw) { alert('No draft found'); return; }
    const d = JSON.parse(raw);
    document.getElementById('fullName').value = d.fullName || '';
    document.getElementById('dob').value = d.dob || '';
    document.getElementById('gender').value = d.gender || '';
    document.getElementById('primaryField').value = d.primaryField || '';
    document.getElementById('subField').value = d.subField || '';
    skills = d.skills || [];
    renderSkills();
    document.getElementById('experience').value = d.experience || '';
    document.getElementById('degree').value = d.degree || '';
    document.getElementById('institution').value = d.institution || '';
    document.getElementById('gradYear').value = d.gradYear || '';
    document.getElementById('email').value = d.email || '';
    document.getElementById('phone').value = d.phone || '';
    document.getElementById('linkedin').value = d.linkedin || '';
    if (document.getElementById('bio')) document.getElementById('bio').value = d.bio || '';
    alert('Draft loaded.');
  });

  // submit to backend
  document.getElementById('nextBtn').addEventListener('click', async () => {
    if (!validate()) { const first = document.querySelector('.error:not(:empty)'); if (first) first.scrollIntoView({behavior:'smooth', block:'center'}); return; }
    const userId = parseInt(localStorage.getItem('userId'), 10);
    if (!userId) { alert('Please sign up / login first'); return; }

    const payload = {
      userId,
      fullName: document.getElementById('fullName').value.trim(),
      dob: document.getElementById('dob').value || null,
      gender: document.getElementById('gender').value || null,
      primaryField: document.getElementById('primaryField').value || null,
      subField: document.getElementById('subField').value || null,
      yearsExperience: parseInt(document.getElementById('experience').value || 0, 10),
      degree: document.getElementById('degree').value || null,
      institution: document.getElementById('institution').value || null,
      gradYear: parseInt(document.getElementById('gradYear').value || 0, 10),
      email: document.getElementById('email').value.trim(),
      phone: document.getElementById('phone').value || null,
      linkedin: document.getElementById('linkedin').value || null,
      bio: document.getElementById('bio') ? document.getElementById('bio').value : null,
      skills
    };

    try {
      const res = await fetch('http://localhost:3000/api/users/individual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (localStorage.getItem('token') || '') },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save profile');
      alert('Profile saved.');
      window.location.href = 'individual_home.html';
    } catch (err) {
      alert('Error: ' + err.message);
    }
  });

  // initial render skills if any
  const draft = localStorage.getItem('individualDraft');
  if (draft) {
    // don't auto-load, but you could: renderSkills();
  }
});
