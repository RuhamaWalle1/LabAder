// frontend/js/organization_reg.js
document.addEventListener('DOMContentLoaded', () => {
  const companyLogo = document.getElementById('companyLogo');
  const logoPreview = document.getElementById('logoPreview');
  const saveBtn = document.getElementById('saveOrgDraft');
  const loadBtn = document.getElementById('loadOrgDraft');
  const submitBtn = document.getElementById('submitOrg');

  companyLogo?.addEventListener('change', () => {
    const file = companyLogo.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => logoPreview.innerHTML = `<img src="${reader.result}" alt="Logo preview">`;
    reader.readAsDataURL(file);
  });

  function showError(id, msg){ const el = document.getElementById(id); if (el) el.textContent = msg; }
  function clearErrors(){ ['err-companyName','err-industry','err-orgEmail'].forEach(id=>{ const el=document.getElementById(id); if(el) el.textContent=''; });}
  function validate(){
    clearErrors();
    let ok = true;
    if (!document.getElementById('companyName').value.trim()){ showError('err-companyName','Company name required'); ok=false; }
    if (!document.getElementById('industry').value){ showError('err-industry','Industry required'); ok=false; }
    const email = document.getElementById('orgEmail').value.trim();
    if (!email || !/^\S+@\S+\.\S+$/.test(email)){ showError('err-orgEmail','Valid contact email required'); ok=false; }
    return ok;
  }

  saveBtn.addEventListener('click', () => {
    const data = {
      companyName: document.getElementById('companyName').value,
      industry: document.getElementById('industry').value,
      description: document.getElementById('description').value,
      city: document.getElementById('city').value,
      state: document.getElementById('state').value,
      country: document.getElementById('country').value,
      orgEmail: document.getElementById('orgEmail').value,
      orgPhone: document.getElementById('orgPhone').value,
      website: document.getElementById('website').value,
      hrName: document.getElementById('hrName').value,
      hrRole: document.getElementById('hrRole').value,
      hrEmail: document.getElementById('hrEmail').value,
      linkedinCompany: document.getElementById('linkedinCompany').value
    };
    localStorage.setItem('orgDraft', JSON.stringify(data));
    alert('Draft saved locally.');
  });

  loadBtn.addEventListener('click', () => {
    const raw = localStorage.getItem('orgDraft');
    if (!raw) { alert('No draft'); return; }
    const d = JSON.parse(raw);
    document.getElementById('companyName').value = d.companyName || '';
    document.getElementById('industry').value = d.industry || '';
    document.getElementById('description').value = d.description || '';
    document.getElementById('city').value = d.city || '';
    document.getElementById('state').value = d.state || '';
    document.getElementById('country').value = d.country || '';
    document.getElementById('orgEmail').value = d.orgEmail || '';
    document.getElementById('orgPhone').value = d.orgPhone || '';
    document.getElementById('website').value = d.website || '';
    document.getElementById('hrName').value = d.hrName || '';
    document.getElementById('hrRole').value = d.hrRole || '';
    document.getElementById('hrEmail').value = d.hrEmail || '';
    document.getElementById('linkedinCompany').value = d.linkedinCompany || '';
    alert('Loaded draft');
  });

  submitBtn.addEventListener('click', async () => {
    if (!validate()) { const first = document.querySelector('.error:not(:empty)'); if (first) first.scrollIntoView({behavior:'smooth',block:'center'}); return; }
    const userId = parseInt(localStorage.getItem('userId'), 10);
    if (!userId) { alert('Please sign up / login first'); return; }

    const payload = {
      userId,
      companyName: document.getElementById('companyName').value.trim(),
      industry: document.getElementById('industry').value || null,
      description: document.getElementById('description').value || null,
      logoUrl: null, // not uploading binary in this version
      city: document.getElementById('city').value || null,
      stateRegion: document.getElementById('state').value || null,
      country: document.getElementById('country').value || null,
      contactEmail: document.getElementById('orgEmail').value.trim(),
      contactPhone: document.getElementById('orgPhone').value || null,
      website: document.getElementById('website').value || null,
      hrName: document.getElementById('hrName').value || null,
      hrRole: document.getElementById('hrRole').value || null,
      hrEmail: document.getElementById('hrEmail').value || null
    };

    try {
      const res = await fetch('http://localhost:3000/api/users/company', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (localStorage.getItem('token') || '') },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      alert('Company profile created.');
      // optionally fetch companyID and store
      // try to fetch company profile to get CompanyID
      const cp = await fetch(`http://localhost:3000/api/users/company/${userId}`);
      const cpjson = await cp.json();
      if (cpok(cpjson)) localStorage.setItem('companyID', cpjson.CompanyID || cpjson.companyID || '');
      window.location.href = 'company_home.html';
    } catch (err) {
      alert('Error: ' + err.message);
    }

    function cpok(j){ return j && (j.CompanyID || j.companyID); }
  });
});
