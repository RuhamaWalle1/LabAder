// frontend/js/individual_home.js
document.addEventListener('DOMContentLoaded', () => {
  const feedEl = document.getElementById('feed');
  const publishBtn = document.getElementById('publishBtn');
  const postText = document.getElementById('postText');
  const attachBtn = document.getElementById('attachBtn');
  const fileAttach = document.getElementById('fileAttach');
  const suggestionsEl = document.getElementById('suggestions');

  let feed = [];
  const suggestions = [
    {name:'Samuel T', role:'Data Analyst'},
    {name:'Aminah K', role:'UX Designer'},
    {name:'Getachew D', role:'Electrical Engineer'}
  ];

  function renderSuggestions(){
    suggestionsEl.innerHTML = '';
    suggestions.forEach((s,idx) => {
      const el = document.createElement('div');
      el.className = 'suggest-item';
      el.innerHTML = `<div style="display:flex;gap:10px;align-items:center">
        <img src="avatar-placeholder.png" style="width:42px;height:42px;border-radius:8px">
        <div><div style="font-weight:700">${s.name}</div><div style="font-size:13px;color:var(--muted)">${s.role}</div></div>
      </div>
      <div><button class="btn ghost" data-idx="${idx}" onclick="connect(this)">Connect</button></div>`;
      suggestionsEl.appendChild(el);
    });
    window.connect = (btn) => {
      const idx = parseInt(btn.dataset.idx,10);
      alert('Connection request sent to ' + suggestions[idx].name);
      btn.textContent = 'Pending'; btn.disabled = true;
    };
  }

  function renderFeed(){
    feedEl.innerHTML = '';
    feed.slice().reverse().forEach(item => {
      if (item.PostID && item.Content){
        const card = document.createElement('div');
        card.className = 'feed-card card';
        card.innerHTML = `<div class="meta"><img src="avatar-placeholder.png"><div style="font-weight:700">${item.Email || 'User'} <div style="font-size:13px;color:var(--muted)">shared</div></div></div>
          <p>${escapeHtml(item.Content)}</p>
          <div class="actions">
            <button class="btn ghost" onclick="likePost(${item.PostID})">👍</button>
            <button class="btn ghost" onclick="savePost(${item.PostID})">Save</button>
          </div>`;
        feedEl.appendChild(card);
      } else if (item.Title && item.CompanyName){
        const card = document.createElement('div');
        card.className = 'feed-card card job-card';
        card.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-weight:800">${item.Title}</div>
              <div style="font-size:13px;color:var(--muted)">${item.CompanyName} · ${item.Location || 'Remote'}</div>
            </div>
            <div>
              <button class="btn ghost" onclick="saveJob(${item.JobID})">Save</button>
            </div>
          </div>
          <div style="margin-top:8px;font-size:13px;color:var(--muted)">${item.CreatedAt ? item.CreatedAt : ''}</div>`;
        feedEl.appendChild(card);
      }
    });

    window.likePost = (id) => { alert('Like (demo). Implement server-side like if required.'); };
    window.savePost = (id) => { alert('Saved (demo). Implement saving posts server-side if needed.'); };
    window.saveJob = (id) => { alert('Saved job (demo).'); };
  }

  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

  async function loadFeed(){
    try {
      const res = await fetch('http://localhost:3000/api/posts');
      const data = await res.json();
      if (!Array.isArray(data)) throw new Error('Invalid feed response');
      feed = data;
      renderFeed();
    } catch (err) {
      console.error(err);
      alert('Could not load feed: ' + err.message);
    }
  }

  publishBtn.addEventListener('click', async () => {
    const text = postText.value.trim();
    if (!text) { alert('Write something'); return; }
    const userId = parseInt(localStorage.getItem('userId'), 10);
    if (!userId) { alert('Please login'); return; }
    try {
      const res = await fetch('http://localhost:3000/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (localStorage.getItem('token') || '') },
        body: JSON.stringify({ userId, content: text })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Post failed');
      postText.value = '';
      await loadFeed();
    } catch (err) {
      alert('Error: ' + err.message);
    }
  });

  attachBtn.addEventListener('click', () => fileAttach.click());
  fileAttach.addEventListener('change', () => {
    const f = fileAttach.files[0];
    if (f) alert('Attachment demo only: ' + f.name);
  });

  renderSuggestions();
  loadFeed();

  // mobile quick post
  document.getElementById('bnPost')?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    postText.focus();
  });
});
