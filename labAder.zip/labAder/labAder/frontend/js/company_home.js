// frontend/js/company_home.js
document.addEventListener('DOMContentLoaded', () => {
  const jobsList = document.getElementById('jobsList');
  const postJobBtn = document.getElementById('postJobBtnC');
  const jobTitle = document.getElementById('jobTitle');
  const jobLocation = document.getElementById('jobLocation');
  const jobType = document.getElementById('jobType');
  const jobDesc = document.getElementById('jobDesc');
  const candidateSuggestions = document.getElementById('candidateSuggestions');

  let jobs = [];

  const candidates = [
    {name:'Hannah M', title:'React Dev', skills:['React','JS']},
    {name:'Kebede S', title:'Backend Engineer', skills:['Node','SQL']},
    {name:'Lina R', title:'Data Scientist', skills:['Python','ML']}
  ];

  function renderCandidates(){
    candidateSuggestions.innerHTML = '';
    candidates.forEach((c, idx) => {
      const el = document.createElement('div');
      el.className = 'suggest-item';
      el.innerHTML = `<div style="display:flex;gap:10px;align-items:center">
        <img src="avatar-placeholder.png" style="width:42px;height:42px;border-radius:8px">
        <div><div style="font-weight:700">${c.name}</div><div style="font-size:13px;color:var(--muted)">${c.title}</div></div>
      </div>
      <div><button class="btn primary" onclick="invite(${idx})">Invite</button></div>`;
      candidateSuggestions.appendChild(el);
    });
    window.invite = (i) => { alert('Invite sent to ' + candidates[i].name); };
  }

  function renderJobs(){
    jobsList.innerHTML = '';
    jobs.slice().reverse().forEach(job => {
      const card = document.createElement('div');
      card.className = 'feed-card card job-card';
      card.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center">
          <div>
            <div style="font-weight:800">${job.Title || job.title}</div>
            <div style="font-size:13px;color:var(--muted)">${job.Location || job.location} · ${job.JobType || job.type}</div>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn ghost" onclick="toggleJob(${job.JobID || job.id})">${(job.IsOpen || job.open) ? 'Close' : 'Open'}</button>
            <button class="btn ghost" onclick="viewApplicants(${job.JobID || job.id})">Applicants</button>
            <button class="btn ghost" onclick="deleteJob(${job.JobID || job.id})">Delete</button>
          </div>
        </div>
        <div style="margin-top:8px;color:var(--muted)">${job.Description || job.desc}</div>
        <div style="margin-top:8px;font-size:13px;color:var(--muted)">Status: <strong>${(job.IsOpen || job.open) ? 'Open' : 'Closed'}</strong></div>`;
      jobsList.appendChild(card);
    });

    window.toggleJob = async (id) => {
      try {
        const res = await fetch(`http://localhost:3000/api/jobs/${id}/close`, { method: 'PUT', headers: { 'Authorization': 'Bearer ' + (localStorage.getItem('token') || '') }});
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed');
        await loadJobsFromServer();
      } catch (err) { alert('Error: ' + err.message); }
    };

    window.viewApplicants = (id) => { alert('View applicants for ' + id + ' (implement view modal)'); };
    window.deleteJob = async (id) => {
      if (!confirm('Delete job?')) return;
      try {
        // optionally: implement DELETE endpoint. For demo, call close then remove locally by reloading.
        await fetch(`http://localhost:3000/api/jobs/${id}/close`, { method: 'PUT', headers: { 'Authorization': 'Bearer ' + (localStorage.getItem('token') || '') }});
        await loadJobsFromServer();
      } catch (err) { alert('Error: ' + err.message); }
    };
  }

  async function loadJobsFromServer(){
    try {
      const res = await fetch('http://localhost:3000/api/jobs');
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to load jobs');
      jobs = data;
      renderJobs();
      document.getElementById('insJobs').textContent = jobs.filter(x => x.IsOpen || x.open).length;
    } catch (err) {
      console.error(err);
      alert('Could not load jobs: ' + err.message);
    }
  }

  postJobBtn.addEventListener('click', async () => {
    const title = jobTitle.value.trim();
    if (!title) { alert('Provide a job title.'); jobTitle.focus(); return; }
    const companyID = parseInt(localStorage.getItem('companyID'), 10) || null;
    if (!companyID) { alert('Company not identified. Please login as company.'); return; }

    const payload = { companyID, title, location: jobLocation.value.trim() || 'Remote', jobType: jobType.value, description: jobDesc.value.trim() };

    try {
      const res = await fetch('http://localhost:3000/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (localStorage.getItem('token') || '') },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to post job');
      jobTitle.value=''; jobLocation.value=''; jobDesc.value='';
      await loadJobsFromServer();
    } catch (err) {
      alert('Error: ' + err.message);
    }
  });

  document.getElementById('saveJobDraft')?.addEventListener('click', () => {
    const draft = { title: jobTitle.value, location: jobLocation.value, type: jobType.value, desc: jobDesc.value };
    localStorage.setItem('companyJobDraft', JSON.stringify(draft));
    alert('Job draft saved locally.');
  });

  renderCandidates();
  loadJobsFromServer();
});
