// backend/routes/auth.js
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { executeSql, TYPES_MAP } = require('../db');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'labader_dev_secret';

// POST /api/auth/signup
router.post('/signup', async (req, res, next) => {
  try {
    const { email, password, userType } = req.body;
    if (!email || !password || !userType) return res.status(400).json({ error: 'email/password/userType required' });

    const exists = await executeSql('SELECT UserID FROM Users WHERE Email = @email', [
      { name: 'email', type: TYPES_MAP.NVarChar, value: email }
    ]);
    if (exists.length) return res.status(400).json({ error: 'User already exists' });

    const hash = await bcrypt.hash(password, 10);
    const rows = await executeSql(
      `INSERT INTO Users (Email, PasswordHash, UserType) OUTPUT INSERTED.UserID VALUES (@email, @hash, @type)`,
      [
        { name: 'email', type: TYPES_MAP.NVarChar, value: email },
        { name: 'hash', type: TYPES_MAP.NVarChar, value: hash },
        { name: 'type', type: TYPES_MAP.NVarChar, value: userType }
      ]
    );
    const userId = rows[0] && rows[0].UserID;
    const token = jwt.sign({ userId, email, userType }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ userId, token });
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email/password required' });

    const rows = await executeSql('SELECT UserID, PasswordHash, UserType FROM Users WHERE Email = @email', [
      { name: 'email', type: TYPES_MAP.NVarChar, value: email }
    ]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });

    const row = rows[0];
    const ok = await bcrypt.compare(password, row.PasswordHash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ userId: row.UserID, email, userType: row.UserType }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ userId: row.UserID, userType: row.UserType, token });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
