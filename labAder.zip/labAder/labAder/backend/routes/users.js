// backend/routes/users.js
const express = require('express');
const { executeSql, TYPES_MAP } = require('../db');

const router = express.Router();

/**
 * POST /api/users/individual
 * payload: { userId, fullName, dob, gender, primaryField, subField, yearsExperience, degree, institution, gradYear, email, phone, linkedin, bio, skills: [..] }
 */
router.post('/individual', async (req, res, next) => {
  try {
    const p = req.body;
    if (!p.userId || !p.fullName) return res.status(400).json({ error: 'userId and fullName required' });

    // check exists
    const exists = await executeSql('SELECT IndividualID FROM IndividualProfiles WHERE UserID = @userId', [
      { name: 'userId', type: TYPES_MAP.Int, value: p.userId }
    ]);

    const params = [
      { name: 'userId', type: TYPES_MAP.Int, value: p.userId },
      { name: 'fullName', type: TYPES_MAP.NVarChar, value: p.fullName || null },
      { name: 'dob', type: TYPES_MAP.Date, value: p.dob || null },
      { name: 'gender', type: TYPES_MAP.NVarChar, value: p.gender || null },
      { name: 'profilePicUrl', type: TYPES_MAP.NVarChar, value: p.profilePicUrl || null },
      { name: 'primaryField', type: TYPES_MAP.NVarChar, value: p.primaryField || null },
      { name: 'subField', type: TYPES_MAP.NVarChar, value: p.subField || null },
      { name: 'yearsExp', type: TYPES_MAP.Int, value: p.yearsExperience || null },
      { name: 'degree', type: TYPES_MAP.NVarChar, value: p.degree || null },
      { name: 'institution', type: TYPES_MAP.NVarChar, value: p.institution || null },
      { name: 'gradYear', type: TYPES_MAP.Int, value: p.gradYear || null },
      { name: 'email', type: TYPES_MAP.NVarChar, value: p.email || null },
      { name: 'phone', type: TYPES_MAP.NVarChar, value: p.phone || null },
      { name: 'linkedin', type: TYPES_MAP.NVarChar, value: p.linkedin || null },
      { name: 'bio', type: TYPES_MAP.NVarChar, value: p.bio || null }
    ];

    let individualID;
    if (exists.length) {
      // update
      await executeSql(
        `UPDATE IndividualProfiles SET FullName=@fullName, DOB=@dob, Gender=@gender, ProfilePicUrl=@profilePicUrl,
         PrimaryField=@primaryField, SubField=@subField, YearsExperience=@yearsExp, Degree=@degree, Institution=@institution,
         GradYear=@gradYear, Email=@email, Phone=@phone, LinkedIn=@linkedin, Bio=@bio WHERE UserID=@userId`,
        params
      );
      const out = await executeSql('SELECT IndividualID FROM IndividualProfiles WHERE UserID = @userId', [
        { name: 'userId', type: TYPES_MAP.Int, value: p.userId }
      ]);
      individualID = out[0].IndividualID;
    } else {
      // insert
      const ins = await executeSql(
        `INSERT INTO IndividualProfiles (UserID, FullName, DOB, Gender, ProfilePicUrl, PrimaryField, SubField, YearsExperience,
             Degree, Institution, GradYear, Email, Phone, LinkedIn, Bio)
         OUTPUT INSERTED.IndividualID
         VALUES (@userId,@fullName,@dob,@gender,@profilePicUrl,@primaryField,@subField,@yearsExp,@degree,@institution,@gradYear,@email,@phone,@linkedin,@bio)`,
        params
      );
      individualID = ins[0] && ins[0].IndividualID;
    }

    // handle skills array: create skill if missing, then insert into IndividualSkills
    const skills = Array.isArray(p.skills) ? p.skills.map(s => String(s).trim()).filter(Boolean) : [];
    for (const skill of skills) {
      // upsert skill
      const found = await executeSql('SELECT SkillID FROM Skills WHERE Name = @name', [
        { name: 'name', type: TYPES_MAP.NVarChar, value: skill }
      ]);
      let skillId;
      if (found.length) {
        skillId = found[0].SkillID;
      } else {
        const insSkill = await executeSql('INSERT INTO Skills (Name) OUTPUT INSERTED.SkillID VALUES (@name)', [
          { name: 'name', type: TYPES_MAP.NVarChar, value: skill }
        ]);
        skillId = insSkill[0] && insSkill[0].SkillID;
      }

      // insert into IndividualSkills if not exists
      if (skillId) {
        const rel = await executeSql('SELECT * FROM IndividualSkills WHERE IndividualID = @ind AND SkillID = @sid', [
          { name: 'ind', type: TYPES_MAP.Int, value: individualID },
          { name: 'sid', type: TYPES_MAP.Int, value: skillId }
        ]);
        if (!rel.length) {
          await executeSql('INSERT INTO IndividualSkills (IndividualID, SkillID) VALUES (@ind, @sid)', [
            { name: 'ind', type: TYPES_MAP.Int, value: individualID },
            { name: 'sid', type: TYPES_MAP.Int, value: skillId }
          ]);
        }
      }
    }

    res.json({ success: true, individualID });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/users/company
 * payload: { userId, companyName, industry, description, logoUrl, city, stateRegion, country, contactEmail, contactPhone, website, hrName, hrRole, hrEmail }
 */
router.post('/company', async (req, res, next) => {
  try {
    const p = req.body;
    if (!p.userId || !p.companyName) return res.status(400).json({ error: 'userId and companyName required' });

    const exists = await executeSql('SELECT CompanyID FROM CompanyProfiles WHERE UserID = @userId', [
      { name: 'userId', type: TYPES_MAP.Int, value: p.userId }
    ]);

    const params = [
      { name: 'userId', type: TYPES_MAP.Int, value: p.userId },
      { name: 'companyName', type: TYPES_MAP.NVarChar, value: p.companyName },
      { name: 'industry', type: TYPES_MAP.NVarChar, value: p.industry || null },
      { name: 'description', type: TYPES_MAP.NVarChar, value: p.description || null },
      { name: 'logoUrl', type: TYPES_MAP.NVarChar, value: p.logoUrl || null },
      { name: 'city', type: TYPES_MAP.NVarChar, value: p.city || null },
      { name: 'stateRegion', type: TYPES_MAP.NVarChar, value: p.stateRegion || null },
      { name: 'country', type: TYPES_MAP.NVarChar, value: p.country || null },
      { name: 'contactEmail', type: TYPES_MAP.NVarChar, value: p.contactEmail || null },
      { name: 'contactPhone', type: TYPES_MAP.NVarChar, value: p.contactPhone || null },
      { name: 'website', type: TYPES_MAP.NVarChar, value: p.website || null },
      { name: 'hrName', type: TYPES_MAP.NVarChar, value: p.hrName || null },
      { name: 'hrRole', type: TYPES_MAP.NVarChar, value: p.hrRole || null },
      { name: 'hrEmail', type: TYPES_MAP.NVarChar, value: p.hrEmail || null }
    ];

    if (exists.length) {
      await executeSql(
        `UPDATE CompanyProfiles SET CompanyName=@companyName, Industry=@industry, Description=@description, LogoUrl=@logoUrl,
         City=@city, StateRegion=@stateRegion, Country=@country, ContactEmail=@contactEmail, ContactPhone=@contactPhone,
         Website=@website, HRName=@hrName, HRRole=@hrRole, HREmail=@hrEmail WHERE UserID=@userId`,
        params
      );
      return res.json({ updated: true });
    } else {
      await executeSql(
        `INSERT INTO CompanyProfiles (UserID, CompanyName, Industry, Description, LogoUrl, City, StateRegion, Country,
             ContactEmail, ContactPhone, Website, HRName, HRRole, HREmail)
         VALUES (@userId,@companyName,@industry,@description,@logoUrl,@city,@stateRegion,@country,@contactEmail,@contactPhone,@website,@hrName,@hrRole,@hrEmail)`,
        params
      );
      return res.status(201).json({ created: true });
    }
  } catch (err) {
    next(err);
  }
});

// GET individual by userId
router.get('/individual/:userId', async (req, res, next) => {
  try {
    const uid = parseInt(req.params.userId, 10);
    const rows = await executeSql('SELECT * FROM IndividualProfiles WHERE UserID = @userId', [
      { name: 'userId', type: TYPES_MAP.Int, value: uid }
    ]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// GET company by userId
router.get('/company/:userId', async (req, res, next) => {
  try {
    const uid = parseInt(req.params.userId, 10);
    const rows = await executeSql('SELECT * FROM CompanyProfiles WHERE UserID = @userId', [
      { name: 'userId', type: TYPES_MAP.Int, value: uid }
    ]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

module.exports = router;
