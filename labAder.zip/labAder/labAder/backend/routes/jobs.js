// backend/routes/jobs.js
const express = require('express');
const { executeSql, TYPES_MAP } = require('../db');

const router = express.Router();

// GET /api/jobs - list open jobs
router.get('/', async (req, res, next) => {
  try {
    const rows = await executeSql(
      `SELECT j.JobID, j.Title, j.Location, j.JobType, j.Description, j.IsOpen, j.CreatedAt, c.CompanyID, c.CompanyName
       FROM Jobs j
       JOIN CompanyProfiles c ON j.CompanyID = c.CompanyID
       WHERE j.IsOpen = 1
       ORDER BY j.CreatedAt DESC`
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// POST /api/jobs - create job
router.post('/', async (req, res, next) => {
  try {
    const { companyID, title, location, jobType, description } = req.body;
    if (!companyID || !title) return res.status(400).json({ error: 'companyID and title required' });

    await executeSql(
      `INSERT INTO Jobs (CompanyID, Title, Location, JobType, Description) VALUES (@companyID, @title, @location, @jobType, @desc)`,
      [
        { name: 'companyID', type: TYPES_MAP.Int, value: companyID },
        { name: 'title', type: TYPES_MAP.NVarChar, value: title },
        { name: 'location', type: TYPES_MAP.NVarChar, value: location || null },
        { name: 'jobType', type: TYPES_MAP.NVarChar, value: jobType || null },
        { name: 'desc', type: TYPES_MAP.NVarChar, value: description || null }
      ]
    );
    res.status(201).json({ created: true });
  } catch (err) { next(err); }
});

// PUT /api/jobs/:id/close
router.put('/:id/close', async (req, res, next) => {
  try {
    const jobId = parseInt(req.params.id, 10);
    await executeSql('UPDATE Jobs SET IsOpen = 0 WHERE JobID = @jobId', [
      { name: 'jobId', type: TYPES_MAP.Int, value: jobId }
    ]);
    res.json({ closed: true });
  } catch (err) { next(err); }
});

// GET /api/jobs/:id/applicants
router.get('/:id/applicants', async (req, res, next) => {
  try {
    const jobId = parseInt(req.params.id, 10);
    const rows = await executeSql(
      `SELECT a.ApplicationID, a.Status, a.AppliedAt, i.IndividualID, i.FullName, i.Email, i.Phone, i.PrimaryField
       FROM Applications a
       JOIN IndividualProfiles i ON a.IndividualID = i.IndividualID
       WHERE a.JobID = @jobId`,
      [{ name: 'jobId', type: TYPES_MAP.Int, value: jobId }]
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// POST /api/jobs/:id/apply  (individual applies to job)
router.post('/:id/apply', async (req, res, next) => {
  try {
    const jobId = parseInt(req.params.id, 10);
    const { individualID } = req.body;
    if (!individualID) return res.status(400).json({ error: 'individualID required' });

    // prevent duplicate application
    const exists = await executeSql('SELECT ApplicationID FROM Applications WHERE JobID=@jobId AND IndividualID=@ind', [
      { name: 'jobId', type: TYPES_MAP.Int, value: jobId },
      { name: 'ind', type: TYPES_MAP.Int, value: individualID }
    ]);
    if (exists.length) return res.status(400).json({ error: 'Already applied' });

    await executeSql('INSERT INTO Applications (JobID, IndividualID) VALUES (@jobId, @ind)', [
      { name: 'jobId', type: TYPES_MAP.Int, value: jobId },
      { name: 'ind', type: TYPES_MAP.Int, value: individualID }
    ]);
    res.status(201).json({ applied: true });
  } catch (err) { next(err); }
});

module.exports = router;
