// backend/routes/posts.js
const express = require('express');
const { executeSql, TYPES_MAP } = require('../db');

const router = express.Router();

// GET /api/posts
router.get('/', async (req, res, next) => {
  try {
    const rows = await executeSql(
      `SELECT p.PostID, p.Content, p.CreatedAt, u.UserID, u.Email, u.UserType
       FROM Posts p
       JOIN Users u ON p.UserID = u.UserID
       ORDER BY p.CreatedAt DESC`
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// POST /api/posts
router.post('/', async (req, res, next) => {
  try {
    const { userId, content } = req.body;
    if (!userId || !content) return res.status(400).json({ error: 'userId and content required' });
    await executeSql(`INSERT INTO Posts (UserID, Content) VALUES (@userId, @content)`, [
      { name: 'userId', type: TYPES_MAP.Int, value: userId },
      { name: 'content', type: TYPES_MAP.NVarChar, value: content.slice(0, 2000) }
    ]);
    res.status(201).json({ created: true });
  } catch (err) { next(err); }
});

module.exports = router;
