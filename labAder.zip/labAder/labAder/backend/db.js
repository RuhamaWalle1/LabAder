// backend/db.js
const { Connection, Request, TYPES } = require('tedious');

const config = {
  server: 'localhost',
  authentication: {
    type: 'default',
    options: {
      userName: 'sa',        // change to your SQL user
      password: 'your_password' // change to your password
    }
  },
  options: {
    database: 'LabAderDB',
    encrypt: false,
    trustServerCertificate: true
  }
};

function executeSql(queryText, params = []) {
  return new Promise((resolve, reject) => {
    const connection = new Connection(config);
    connection.on('connect', (err) => {
      if (err) return reject(err);

      const request = new Request(queryText, (err) => {
        if (err) {
          connection.close();
          return reject(err);
        }
      });

      const rows = [];
      request.on('row', (columns) => {
        const row = {};
        columns.forEach(col => row[col.metadata.colName] = col.value);
        rows.push(row);
      });

      request.on('requestCompleted', () => {
        connection.close();
        resolve(rows);
      });

      // Add parameters
      params.forEach(p => {
        // p = { name, type, value }
        request.addParameter(p.name, p.type, p.value);
      });

      connection.execSql(request);
    });

    connection.on('error', (err) => {
      reject(err);
    });
  });
}

const TYPES_MAP = {
  Int: TYPES.Int,
  NVarChar: TYPES.NVarChar,
  Date: TYPES.Date,
  Bit: TYPES.Bit
};

module.exports = { executeSql, TYPES_MAP, TYPES };
