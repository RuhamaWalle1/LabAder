-- ===============================================
-- LabAderDB - Professional Social Media Platform
-- ===============================================

-- 1️⃣ Create database
CREATE DATABASE LabAderDB;
GO
USE LabAderDB;
GO

-- labader_seed.sql
-- Creates LabAderDB schema (if not already created) and inserts realistic sample data
-- Run in SQL Server (SSMS). Adjust or remove GO lines if your environment behaves differently.

-- 1) Create database and switch
IF DB_ID('LabAderDB') IS NULL
BEGIN
  CREATE DATABASE LabAderDB;
END
GO

USE LabAderDB;
GO

-- 2) Create tables (schema you provided)
-- (If you already created them, skip the CREATE TABLE blocks)
IF OBJECT_ID('Users') IS NULL
BEGIN
-- Users
CREATE TABLE Users (
  UserID INT IDENTITY(1,1) PRIMARY KEY,
  Email NVARCHAR(150) NOT NULL UNIQUE,
  PasswordHash NVARCHAR(255) NOT NULL,
  UserType NVARCHAR(20) NOT NULL CHECK (UserType IN ('INDIVIDUAL','COMPANY')),
  CreatedAt DATETIME2 DEFAULT SYSUTCDATETIME()
);
END
GO

IF OBJECT_ID('IndividualProfiles') IS NULL
BEGIN
CREATE TABLE IndividualProfiles (
  IndividualID INT IDENTITY(1,1) PRIMARY KEY,
  UserID INT NOT NULL UNIQUE,
  FullName NVARCHAR(150),
  DOB DATE NULL,
  Gender NVARCHAR(20) NULL,
  ProfilePicUrl NVARCHAR(500) NULL,
  PrimaryField NVARCHAR(100) NULL,
  SubField NVARCHAR(100) NULL,
  YearsExperience INT NULL,
  Degree NVARCHAR(100) NULL,
  Institution NVARCHAR(200) NULL,
  GradYear INT NULL,
  Email NVARCHAR(150) NULL,
  Phone NVARCHAR(50) NULL,
  LinkedIn NVARCHAR(300) NULL,
  Bio NVARCHAR(1000) NULL,
  FOREIGN KEY (UserID) REFERENCES Users(UserID)
);
END
GO

IF OBJECT_ID('CompanyProfiles') IS NULL
BEGIN
CREATE TABLE CompanyProfiles (
  CompanyID INT IDENTITY(1,1) PRIMARY KEY,
  UserID INT NOT NULL UNIQUE,
  CompanyName NVARCHAR(200) NOT NULL,
  Industry NVARCHAR(100) NULL,
  Description NVARCHAR(1000) NULL,
  LogoUrl NVARCHAR(500) NULL,
  City NVARCHAR(100) NULL,
  StateRegion NVARCHAR(100) NULL,
  Country NVARCHAR(100) NULL,
  ContactEmail NVARCHAR(150) NULL,
  ContactPhone NVARCHAR(50) NULL,
  Website NVARCHAR(300) NULL,
  HRName NVARCHAR(150) NULL,
  HRRole NVARCHAR(150) NULL,
  HREmail NVARCHAR(150) NULL,
  CreatedAt DATETIME2 DEFAULT SYSUTCDATETIME(),
  FOREIGN KEY (UserID) REFERENCES Users(UserID)
);
END
GO

IF OBJECT_ID('Skills') IS NULL
BEGIN
CREATE TABLE Skills (
  SkillID INT IDENTITY(1,1) PRIMARY KEY,
  Name NVARCHAR(100) UNIQUE NOT NULL
);
END
GO

IF OBJECT_ID('IndividualSkills') IS NULL
BEGIN
CREATE TABLE IndividualSkills (
  IndividualID INT NOT NULL,
  SkillID INT NOT NULL,
  PRIMARY KEY (IndividualID, SkillID),
  FOREIGN KEY (IndividualID) REFERENCES IndividualProfiles(IndividualID),
  FOREIGN KEY (SkillID) REFERENCES Skills(SkillID)
);
END
GO

IF OBJECT_ID('Posts') IS NULL
BEGIN
CREATE TABLE Posts (
  PostID INT IDENTITY(1,1) PRIMARY KEY,
  UserID INT NOT NULL,
  Content NVARCHAR(2000),
  CreatedAt DATETIME2 DEFAULT SYSUTCDATETIME(),
  FOREIGN KEY (UserID) REFERENCES Users(UserID)
);
END
GO

IF OBJECT_ID('Jobs') IS NULL
BEGIN
CREATE TABLE Jobs (
  JobID INT IDENTITY(1,1) PRIMARY KEY,
  CompanyID INT NOT NULL,
  Title NVARCHAR(200) NOT NULL,
  Location NVARCHAR(200) NULL,
  JobType NVARCHAR(50) NULL,
  Description NVARCHAR(2000) NULL,
  IsOpen BIT DEFAULT 1,
  CreatedAt DATETIME2 DEFAULT SYSUTCDATETIME(),
  FOREIGN KEY (CompanyID) REFERENCES CompanyProfiles(CompanyID)
);
END
GO

IF OBJECT_ID('Applications') IS NULL
BEGIN
CREATE TABLE Applications (
  ApplicationID INT IDENTITY(1,1) PRIMARY KEY,
  JobID INT NOT NULL,
  IndividualID INT NOT NULL,
  Status NVARCHAR(50) DEFAULT 'APPLIED',
  AppliedAt DATETIME2 DEFAULT SYSUTCDATETIME(),
  FOREIGN KEY (JobID) REFERENCES Jobs(JobID),
  FOREIGN KEY (IndividualID) REFERENCES IndividualProfiles(IndividualID)
);
END
GO

-- 3) Insert sample Users (14 users: 7 individuals, 7 companies)
-- Using a placeholder bcrypt-like hash for demo. Replace with real hashes in production.
DECLARE @pwd NVARCHAR(255) = N'$2b$10$EXAMPLEHASHABCDEFGHIJKLMN1234567890abcdefghi';

INSERT INTO Users (Email, PasswordHash, UserType) VALUES
(N'alice.tadesse@example.com', @pwd, N'INDIVIDUAL'),    -- UserID = 1
(N'bob.moges@example.com', @pwd, N'INDIVIDUAL'),        -- 2
(N'carol.hana@example.com', @pwd, N'INDIVIDUAL'),       -- 3
(N'david.kebede@example.com', @pwd, N'INDIVIDUAL'),     -- 4
(N'emma.yosef@example.com', @pwd, N'INDIVIDUAL'),       -- 5
(N'fahim.ahmed@example.com', @pwd, N'INDIVIDUAL'),      -- 6
(N'gisele.tigist@example.com', @pwd, N'INDIVIDUAL'),    -- 7
-- Companies (these are user accounts used to manage company profiles)
(N'acme.hr@example.com', @pwd, N'COMPANY'),              -- 8
(N'globex.hr@example.com', @pwd, N'COMPANY'),            -- 9
(N'initech.hr@example.com', @pwd, N'COMPANY'),           -- 10
(N'starlabs.hr@example.com', @pwd, N'COMPANY'),          -- 11
(N'nova.hr@example.com', @pwd, N'COMPANY'),              -- 12
(N'bluewave.hr@example.com', @pwd, N'COMPANY'),          -- 13
(N'digitech.hr@example.com', @pwd, N'COMPANY');          -- 14
GO

-- 4) Insert IndividualProfiles for UserID 1..7
INSERT INTO IndividualProfiles 
(UserID, FullName, DOB, Gender, ProfilePicUrl, PrimaryField, SubField, YearsExperience, Degree, Institution, GradYear, Email, Phone, LinkedIn, Bio)
VALUES
(1, N'Alice Tadesse', '1994-05-14', N'Female', N'/images/profiles/alice.jpg', N'Software & IT', N'Frontend Developer', 4, N'Bachelor''s', N'Addis Ababa University', 2019, N'alice.tadesse@example.com', N'+251911123456', N'https://linkedin.com/in/alicetadesse', N'Frontend-focused developer — React & accessibility enthusiast.'),
(2, N'Bob Moges', '1990-11-02', N'Male', N'/images/profiles/bob.jpg', N'Data Science', N'Data Analyst', 6, N'Master''s', N'University of Nairobi', 2018, N'bob.moges@example.com', N'+251911234567', N'https://linkedin.com/in/bobmoges', N'Data analyst with experience building dashboards and ETL pipelines.'),
(3, N'Carol Hana', '1996-07-28', N'Female', N'/images/profiles/carol.jpg', N'Design & Creative', N'UX Designer', 3, N'Bachelor''s', N'Addis Ababa Institute of Design', 2020, N'carol.hana@example.com', N'+251911345678', N'https://linkedin.com/in/carolhana', N'UX designer focusing on user research and accessible interfaces.'),
(4, N'David Kebede', '1987-03-10', N'Male', N'/images/profiles/david.jpg', N'Engineering', N'Electrical Engineer', 10, N'Bachelor''s', N'Jimma University', 2013, N'david.kebede@example.com', N'+251911456789', N'https://linkedin.com/in/davidkebede', N'Experienced in power systems and hardware prototyping.'),
(5, N'Emma Yosef', '1998-12-05', N'Female', N'/images/profiles/emma.jpg', N'Software & IT', N'Backend Engineer', 2, N'Bachelor''s', N'Addis Ababa University', 2022, N'emma.yosef@example.com', N'+251911567890', N'https://github.com/emmayosef', N'Backend developer working with Node.js and SQL.'),
(6, N'Fahim Ahmed', '1992-09-21', N'Male', N'/images/profiles/fahim.jpg', N'Data Science', N'Machine Learning Engineer', 5, N'Master''s', N'University of Cape Town', 2020, N'fahim.ahmed@example.com', N'+251911678901', N'https://linkedin.com/in/fahimahmed', N'ML engineer — Python, scikit-learn, and basic MLOps.'),
(7, N'Gisele Tigist', '1995-04-18', N'Female', N'/images/profiles/gisele.jpg', N'Business & Management', N'Project Manager', 6, N'Bachelor''s', N'Addis Ababa University', 2017, N'gisele.tigist@example.com', N'+251911789012', N'https://linkedin.com/in/giseletigist', N'Experienced project manager in business operations.');
GO

-- 5) Insert CompanyProfiles for UserID 8..14 (CompanyID will be 1..7)
INSERT INTO CompanyProfiles (UserID, CompanyName, Industry, Description, LogoUrl, City, StateRegion, Country, ContactEmail, ContactPhone, Website, HRName, HRRole, HREmail)
VALUES
(8, N'Acme Corporation', N'Software & IT', N'Acme builds web platforms and e-commerce experiences for global clients.', N'/images/logos/acme.png', N'Addis Ababa', N'Addis Ababa', N'Ethiopia', N'acme.contact@example.com', N'+251911800001', N'https://acme.example.com', N'Helen W', N'Head of Talent', N'acme.hr@example.com'),
(9, N'Globex Solutions', N'Data & Analytics', N'Globex provides analytics consulting and data engineering services.', N'/images/logos/globex.png', N'Addis Ababa', N'Addis Ababa', N'Ethiopia', N'contact@globex.example', N'+251911800002', N'https://globex.example.com', N'Marcus L', N'HR Manager', N'globex.hr@example.com'),
(10, N'Initech', N'Software & IT', N'Initech builds internal tooling and SaaS products for SMBs.', N'/images/logos/initech.png', N'Bahir Dar', N'Amhara', N'Ethiopia', N'hr@initech.example', N'+251911800003', N'https://initech.example.com', N'Sara D', N'Talent Lead', N'initech.hr@example.com'),
(11, N'StarLabs', N'R&D / Advanced Tech', N'StarLabs focuses on research projects and advanced prototyping.', N'/images/logos/starlabs.png', N'Addis Ababa', N'Addis Ababa', N'Ethiopia', N'recruit@starlabs.example', N'+251911800004', N'https://starlabs.example.com', N'Peter Q', N'HR Partner', N'starlabs.hr@example.com'),
(12, N'Nova Health', N'Healthcare', N'Nova Health builds healthcare SaaS and data platforms.', N'/images/logos/nova.png', N'Gondar', N'Amhara', N'Ethiopia', N'contact@nova.example', N'+251911800005', N'https://nova.example.com', N'Linda S', N'Head of People', N'nova.hr@example.com'),
(13, N'BlueWave', N'Design & Creative', N'BlueWave is a digital studio focusing on UX and product design.', N'/images/logos/bluewave.png', N'Addis Ababa', N'Addis Ababa', N'Ethiopia', N'hr@bluewave.example', N'+251911800006', N'https://bluewave.example.com', N'Rahul P', N'HR Manager', N'bluewave.hr@example.com'),
(14, N'DigiTech', N'Technology', N'DigiTech specializes in cloud infrastructure and devops solutions.', N'/images/logos/digitech.png', N'Adama', N'Oromia', N'Ethiopia', N'careers@digitech.example', N'+251911800007', N'https://digitech.example.com', N'Adane K', N'People Ops', N'digitech.hr@example.com');
GO

-- 6) Insert a set of Skills (10 skills)
INSERT INTO Skills (Name) VALUES
(N'JavaScript'),   -- SkillID = 1
(N'React'),        -- 2
(N'Node.js'),      -- 3
(N'SQL'),          -- 4
(N'Python'),       -- 5
(N'Data Science'), -- 6
(N'UX Design'),    -- 7
(N'Electrical Engineering'), -- 8
(N'Project Management'), -- 9
(N'AWS');          -- 10
GO

-- 7) Assign IndividualSkills (map skills to the 7 individuals)
-- IndividualIDs 1..7 correspond to the inserted IndividualProfiles
-- We'll give each individual 2-4 skills
INSERT INTO IndividualSkills (IndividualID, SkillID) VALUES
(1, 1), (1, 2), (1, 4),        -- Alice: JavaScript, React, SQL
(2, 5), (2, 4), (2, 6),        -- Bob: Python, SQL, Data Science
(3, 7), (3, 1),                -- Carol: UX Design, JavaScript
(4, 8), (4, 9),                -- David: Electrical Engineering, Project Management
(5, 3), (5, 4),                -- Emma: Node.js, SQL
(6, 5), (6, 6), (6, 10),       -- Fahim: Python, Data Science, AWS
(7, 9), (7, 3);                -- Gisele: Project Management, Node.js
GO

-- 8) Insert Posts (feed) — mix of individuals and companies (at least 7)
-- Posts reference Users.UserID (1..14)
INSERT INTO Posts (UserID, Content) VALUES
(1, N'Just published a new personal website — tips welcome! #frontend #react'),
(2, N'Exploring time-series forecasting for sales — any good resources?'),
(3, N'Conducted a micro-usability study this week — sharing findings soon.'),
(8, N'Acme is hiring frontend developers. Apply via our careers page.'),
(10, N'Initech announces new open role: Backend Engineer (remote-friendly).'),
(6, N'Shared a notebook on model evaluation and reproducibility.'),
(11, N'StarLabs looking for R&D engineers with prototyping experience.'),
(12, N'Nova Health: we are expanding our engineering team — contact HR for details.'),
(5, N'Short primer on Node.js performance optimizations posted.'),
(14, N'DigiTech launching a cloud-first internship program this summer.');
GO

-- 9) Insert Jobs (at least 7 jobs), each referencing CompanyID 1..7 (companies mapped to userIDs 8..14)
-- CompanyID 1 -> Acme, 2 -> Globex, 3 -> Initech, 4 -> Starlabs, 5 -> Nova, 6 -> BlueWave, 7 -> DigiTech
INSERT INTO Jobs (CompanyID, Title, Location, JobType, Description, IsOpen)
VALUES
(1, N'Frontend Developer', N'Addis Ababa', N'Full-time', N'Work on customer-facing React applications and accessibility improvements.', 1),
(2, N'Data Engineer', N'Addis Ababa / Remote', N'Full-time', N'Build data pipelines and ETL processes for analytics projects.', 1),
(3, N'Backend Engineer', N'Remote', N'Full-time', N'API development with Node.js and scalable database design.', 1),
(4, N'Prototype Engineer', N'Addis Ababa', N'Contract', N'Rapid prototyping for hardware and embedded systems.', 1),
(5, N'Healthcare Software Engineer', N'Gondar', N'Full-time', N'Build and maintain SaaS platforms for clinics.', 1),
(6, N'Product Designer (UX)', N'Addis Ababa', N'Full-time', N'Lead UX efforts for web & mobile products.', 1),
(7, N'Cloud DevOps Engineer', N'Adama', N'Full-time', N'Manage AWS infrastructure, CI/CD and observability.', 1),
(1, N'Junior Frontend Developer', N'Remote', N'Part-time', N'Entry-level role for junior developers learning React.', 1);
GO

-- 10) Insert Applications (at least 7) — Individuals applying to jobs
-- We'll create a few realistic matches
-- Note: JobIDs will be 1..8 in order inserted above
INSERT INTO Applications (JobID, IndividualID, Status)
VALUES
(1, 1, N'APPLIED'),  -- Alice applied to Acme Frontend
(2, 2, N'SHORTLISTED'), -- Bob to Globex Data Engineer
(3, 5, N'APPLIED'), -- Emma to Initech Backend
(4, 4, N'APPLIED'), -- David to Starlabs Prototype
(6, 3, N'APPLIED'), -- Carol to BlueWave Product Designer
(7, 6, N'APPLIED'), -- Fahim to DigiTech Cloud DevOps
(1, 5, N'APPLIED'), -- Emma also applied to Acme Frontend
(8, 7, N'APPLIED'); -- Gisele applied to Junior Frontend (Acme)
GO

-- 11) Quick verification queries (optional) - uncomment to run
SELECT COUNT(*) AS UsersCount FROM Users;
SELECT COUNT(*) AS Individuals FROM IndividualProfiles;
SELECT COUNT(*) AS Companies FROM CompanyProfiles;
SELECT s.SkillID, s.Name, COUNT(isf.IndividualID) AS Holds FROM Skills s LEFT JOIN IndividualSkills isf ON s.SkillID = isf.SkillID GROUP BY s.SkillID, s.Name ORDER BY s.SkillID;
SELECT j.JobID, j.Title, c.CompanyName FROM Jobs j JOIN CompanyProfiles c ON j.CompanyID = c.CompanyID ORDER BY j.CreatedAt DESC;

-- Done
PRINT 'LabAderDB seeded with sample data.';
GO
